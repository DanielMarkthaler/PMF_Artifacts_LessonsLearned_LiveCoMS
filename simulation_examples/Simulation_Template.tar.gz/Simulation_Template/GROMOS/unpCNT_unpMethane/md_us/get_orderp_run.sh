#!/bin/bash 

input=trs.arg
output=trs.out
program=trs_ana

for x in l?.???; do
	echo $x
	cd $x >/dev/null
	if [ -s $output ]; then
		echo "$x/$output exists"
	else
		if [ -s $input ]; then
			$program @f $input > $output
		else
			echo "$x not done yet"
		fi
	fi
	cd ..
done
