#!/usr/bin/env python 
import os, glob

properties = ['orderp']
namebase = os.path.basename(os.path.normpath(os.getcwd()))
direc = glob.glob('./l*')
print direc

# get topology from mk_script file
for line in open("md_mk_script.arg"):
	if ".top" in line:
		print line
		topology=line.split()[-1]
		break

for file in direc:
	La = file.split("l")[-1]
	trajectories = glob.glob(file + '/*trs.gz')
	trajectories.sort()
	print trajectories, len(trajectories)
	cnt = 1
	if len(trajectories) > 1:
		f=open(file +'/trs.arg','w')
		f.write('@trs ')
		for trj in trajectories:
			#print trj
			trj_short = trj.split("/")[-1]
			if cnt == 0: 
				cnt += 1
				pass
			else: 
				f.write(trj_short + '\n')
				cnt = cnt+1
        	f.write('@prop \n')
        	for prp in properties:
			f.write(prp + '\n')
        	f.write('@topo  ../' + topology + '\n')
		f.write('@time 0 0.2\n')
		f.write('@library ../../lib/trs.lib\n')
		f.close()
