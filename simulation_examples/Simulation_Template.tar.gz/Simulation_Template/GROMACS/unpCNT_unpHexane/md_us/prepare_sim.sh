#!/bin/bash

function gen_plumedfile {
     	# initialize a local var
     	if [ "$2" == "equi" ]
     	then
     	  local file="plumed_eq.dat"
     	else #"$2" = "prod"
     	  local file="plumed_pr.dat"
     	fi
	echo "#DEFINE GROUPS" >> $file
	echo "HOST: GROUP ATOMS=1-140" >> $file
	echo "HOST_left: GROUP ATOMS=5,9,13,17,21,25,29" >> $file
	echo "HOST_right: GROUP ATOMS=60,89,95,101,107,113,119" >> $file
	echo "DUM: GROUP ATOMS=141" >> $file
	echo "LIG: GROUP ATOMS=142-147" >> $file
	echo "LIG_Head: GROUP ATOMS=142" >> $file
	echo "LIG_Tail: GROUP ATOMS=147" >> $file
	echo "#" >> $file
	echo "COM_HOST: COM ATOMS=HOST" >> $file
	echo "COM_HOST_left: COM ATOMS=HOST_left" >> $file
	echo "COM_HOST_right: COM ATOMS=HOST_right" >> $file
	echo "COM_LIG: COM ATOMS=LIG" >> $file
	echo "#DEFINE z-AXIS" >> $file
	echo "a: FIXEDATOM AT=0,0,0" >> $file
	echo "b: FIXEDATOM AT=0,0,1" >> $file
	echo "c: FIXEDATOM AT=1.7,1.7,6.0" >> $file
	echo "#DEFINE GEOMETRIC QUANTITIES" >> $file
	echo "#Orientation" >> $file
	echo "angle_Ori_H: ANGLE ATOMS=b,a,COM_HOST_left,COM_HOST_right" >> $file
	echo "angle_Ori_L: ANGLE ATOMS=a,b,LIG_Head,LIG_Tail" >> $file
	echo "#Host - Ligand" >> $file
	echo "angle_Ori_HL: ANGLE ATOMS=COM_HOST_left,COM_HOST_right,LIG_Head,LIG_Tail" >> $file
	echo "delta_ori: MATHEVAL ARG=angle_Ori_H,angle_Ori_L FUNC=abs(x-y) PERIODIC=NO" >> $file
	echo "phi_HL: ANGLE ATOMS=COM_HOST_left,COM_HOST_right,COM_LIG,COM_HOST" >> $file
	echo "cos_phi_HL: MATHEVAL ARG=phi_HL FUNC=cos(x) PERIODIC=NO" >> $file
	echo "sin_phi_HL: MATHEVAL ARG=phi_HL FUNC=sin(x) PERIODIC=NO" >> $file
	echo "dist_HL: DISTANCE ATOMS=COM_HOST,COM_LIG" >> $file
	echo "dist_HL_cart: DISTANCE ATOMS=COM_HOST,COM_LIG COMPONENTS" >> $file
	echo "OP_1_HL: MATHEVAL ARG=dist_HL,cos_phi_HL FUNC=x*y PERIODIC=NO" >> $file
	echo "OP_2_HL: MATHEVAL ARG=dist_HL,sin_phi_HL FUNC=x*y PERIODIC=NO" >> $file
	echo "dr2: COMBINE ARG=dist_HL_cart.x,dist_HL_cart.y POWERS=2,2 PERIODIC=NO" >> $file
	echo "dr: COMBINE ARG=dr2 POWERS=0.5 PERIODIC=NO" >> $file
	echo "#Host - Dummy" >> $file
	echo "dist_HD: DISTANCE ATOMS=COM_HOST,DUM" >> $file
	echo "#Host-Box center" >> $file
	echo "dist_Hc: DISTANCE ATOMS=COM_HOST,c" >> $file
	echo "#DEFINE RESTRAINTS" >> $file
	echo "posrest_H: RESTRAINT ARG=dist_Hc KAPPA=500.0 AT=0.0" >> $file
	echo "orirest_H: RESTRAINT ARG=angle_Ori_H KAPPA=500.0 AT=0.0" >> $file
	echo "disrest_HD: RESTRAINT ARG=dist_HD KAPPA=1000.0 AT=0.0" >> $file
        if [ "$2" == "equi" ]
        then
		echo "disrest_HL: RESTRAINT ARG=OP_1_HL KAPPA=500.0 AT=$1" >> $file
        else #"$2" = "prod"
		echo "disrest_HL: RESTRAINT ARG=OP_1_HL KAPPA=500.0 AT=$1" >> $file
        fi
	echo "posrest_L: UPPER_WALLS ARG=OP_2_HL AT=0.4 KAPPA=500.0 EPS=1.0 EXP=2.0 OFFSET=0.0" >> $file
	echo "orirest_H_L: RESTRAINT ARG=angle_Ori_HL KAPPA=500.0 AT=0.0" >> $file
	echo "#PRINT TO FILE" >> $file
	echo "PRINT ARG=OP_1_HL,dist_HL_cart.z,dist_HL,OP_2_HL,dr,phi_HL,angle_Ori_H,angle_Ori_L,angle_Ori_HL,delta_ori,disrest_HL.bias,posrest_L.bias,orirest_H_L.bias STRIDE=100 FILE=COLVAR_$1" >> $file
	echo "ENDPLUMED" >> $file
}

window=($(LC_NUMERIC="C" awk 'BEGIN{ for (i=-2.5; i < 2.501; i+=0.1) printf("%.2f\n", i); }'))
length=${#window[@]}

for (( i=0; i<$length; i++ )){
	mkdir w_${window[$i]}
	cd w_${window[$i]}
	gen_plumedfile ${window[$i]} equi
	gen_plumedfile ${window[$i]} prod
	cp ../job_prod.sh .
	cd ../ 
}
