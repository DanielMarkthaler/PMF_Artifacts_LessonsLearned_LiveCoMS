#!/bin/bash

#---------------------------------------------------------------------
#TO BE MODIFIED
#LOAD PREINSTALLED MODULES
module purge
module load compiler/gnu/4.9
module load mpi/openmpi/1.10-gnu-4.9
module load devel/cmake/3.6.1
module load devel/cuda/7.5
module load numlib/openblas/0.2.18-gnu-4.9

#PATH TO INSTALLATION DIRECTORIES
source ~/Programs/plumed-2.4.2/sourceme.sh
source ~/Programs/gromacs-2016.4_plumed-2.4_INSTALL/bin/GMXRC
#---------------------------------------------------------------------

window=($(LC_NUMERIC="C" awk 'BEGIN{ for (i=-2.5; i < 2.501; i+=0.1) printf("%.2f\n", i); }'))
length=${#window[@]}

for (( i=0; i<$length; i++ )){
  cd w_${window[$i]}
  gmx_mpi grompp -f ../../input/us_pr.mdp  -c us_eq.gro -p ../../topo/topol.top -o us_pr.tpr
  qsub job_prod.sh
  cd ../ 
}
